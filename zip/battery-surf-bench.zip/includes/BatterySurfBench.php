<?php
/**
 * Plugin bootstrap.
 *
 * @package ErdemBircan\BatterySurfBench
 */

namespace ErdemBircan\BatterySurfBench;

use ErdemBircan\BatterySurfBench\Admin\Menu;
use ErdemBircan\BatterySurfBench\Admin\SessionsScreen;
use ErdemBircan\BatterySurfBench\Cockpit\Cockpit;
use ErdemBircan\BatterySurfBench\Cockpit\Views\CockpitDashboard;
use ErdemBircan\BatterySurfBench\Cockpit\Views\SessionDetailView;
use ErdemBircan\BatterySurfBench\Cockpit\CoursePagesSource;
use ErdemBircan\BatterySurfBench\Content\SessionDetail;
use ErdemBircan\BatterySurfBench\Content\SessionRestQuery;
use ErdemBircan\BatterySurfBench\Content\SessionSchema;
use ErdemBircan\BatterySurfBench\Content\SessionType;
use ErdemBircan\BatterySurfBench\Course\CourseCatalog;
use ErdemBircan\BatterySurfBench\Course\CourseLibrary;
use ErdemBircan\BatterySurfBench\Course\CourseRouter;
use ErdemBircan\BatterySurfBench\DevTools\DevTools;
use ErdemBircan\BatterySurfBench\DevTools\Views\DevToolsPanelView;
use ErdemBircan\BatterySurfBench\Support\Manager;
use ErdemBircan\BatterySurfBench\Support\StandaloneChrome;

use function explode;

defined( 'ABSPATH' ) || exit;

/**
 * Bootstraps the Battery Surf Bench plugin.
 */
class BatterySurfBench {

	/**
	 * The plugin's read-only configuration registry. Owned solely by the
	 * bootstrap; components receive only the values they need, never the
	 * registry itself.
	 *
	 * @var Registry
	 */
	private Registry $registry;

	/**
	 * Resolves filesystem paths and URLs for the assets shipped with the plugin.
	 *
	 * @var Paths
	 */
	private Paths $paths;

	/**
	 * Enqueues the plugin's script and style files.
	 *
	 * @var Assets
	 */
	private Assets $assets;

	/**
	 * Stores the plugin file path. No work is done here so the object can be
	 * constructed without side effects.
	 *
	 * @param string $plugin_file Absolute path to the main plugin file.
	 */
	public function __construct( private string $plugin_file ) {
	}

	/**
	 * Boots the plugin: builds the registry, path resolver and asset service,
	 * then registers its managers.
	 */
	public function init(): void {
		$this->registry = new Registry( require __DIR__ . '/Config.php' );
		$this->paths    = new Paths( $this->plugin_file );
		$this->assets   = new Assets( $this->registry->get( 'namespace' ), $this->paths );

		foreach ( $this->managers() as $manager ) {
			$manager->register();
		}
	}

	/**
	 * Builds the managers that make up the plugin. The bootstrap reads each
	 * manager's dependencies from the registry and injects only those, so a
	 * manager never reaches the registry itself.
	 *
	 * @return Manager[] The plugin's managers.
	 */
	private function managers(): array {
		$schema = new SessionSchema(
			$this->registry->get( 'session.post_type' ),
			$this->registry->get( 'session.meta_prefix' )
		);

		// Course domain: the catalog describes the surf course and loads each
		// page's block markup; the router serves a page off the course query
		// parameter (rendered through the theme), and the library lists the
		// pages' surf URLs for the cockpit.
		$catalog = new CourseCatalog( $this->paths->path( 'includes/Course/content' ) );
		$library = new CourseLibrary( $catalog, $this->registry->get( 'course.param' ) );

		return array(
			// Loads the plugin's PHP translations on `init` before any manager
			// hooked there renders a translatable string.
			new I18n(
				$this->registry->get( 'namespace' ),
				$this->plugin_file
			),
			new Menu(
				$this->registry->get( 'admin_menu.slug' ),
				$this->registry->get( 'capability' ),
				$this->registry->get( 'admin_menu.icon' ),
				$this->registry->get( 'admin_menu.style' ),
				$this->assets
			),
			new SessionType(
				$schema,
				$this->registry->get( 'capability' )
			),
			new SessionRestQuery( $schema ),
			new SessionsScreen(
				$this->registry->get( 'admin_menu.slug' ),
				$this->registry->get( 'session.screen_slug' ),
				$this->registry->get( 'capability' ),
				$this->registry->get( 'session.bundle' ),
				$this->registry->get( 'session.style' ),
				$schema,
				$this->assets,
				$this->registry->get( 'cockpit.param' ),
				$this->registry->get( 'cockpit.value' )
			),
			new CourseRouter(
				$catalog,
				$this->registry->get( 'course.param' ),
				$this->assets,
				$this->registry->get( 'course.style' ),
				$this->registry->get( 'course.script' )
			),
			new CoursePagesSource(
				$this->registry->get( 'course.binding_source' ),
				$library
			),
			new Cockpit(
				$this->paths->path( $this->registry->get( 'cockpit.block_dir' ) ),
				$this->registry->get( 'cockpit.block_name' ),
				$this->registry->get( 'course.binding_source' ),
				$this->registry->get( 'cockpit.param' ),
				$this->registry->get( 'cockpit.value' ),
				$this->registry->get( 'capability' ),
				new CockpitDashboard(),
				$this->assets,
				$this->registry->get( 'session.post_type' ),
				new StandaloneChrome(
					$this->assets,
					$this->registry->get( 'cockpit.style' )
				)
			),
			// The session detail screen renders the summary postcard on each
			// session's native admin edit screen, replacing the editor. It reuses
			// the cockpit's view module (where the `bsb/cockpit` store is
			// registered) and the cockpit stylesheet (where the postcard styles
			// live), seeding the stored run onto the context.
			new SessionDetail(
				$this->registry->get( 'session.post_type' ),
				$this->registry->get( 'session.meta_prefix' ),
				$this->registry->get( 'capability' ),
				$this->registry->get( 'cockpit.block_name' ),
				$this->registry->get( 'session.screen_slug' ),
				$this->registry->get( 'cockpit.style' ),
				new SessionDetailView(),
				$this->assets
			),
			// Environment-gated dev tools: a floating panel (and the Interactivity
			// module it joins the cockpit store from) that lets battery behaviour be
			// forced for testing, active only in a development environment. Its own
			// gate closes registration entirely outside one, so nothing here reaches
			// a production site.
			new DevTools(
				explode( ',', $this->registry->get( 'devtools.environments' ) ),
				$this->registry->get( 'devtools.module' ),
				$this->registry->get( 'devtools.style' ),
				$this->assets,
				$this->registry->get( 'cockpit.param' ),
				$this->registry->get( 'cockpit.value' ),
				$this->registry->get( 'session.post_type' ),
				new DevToolsPanelView()
			),
		);
	}
}
