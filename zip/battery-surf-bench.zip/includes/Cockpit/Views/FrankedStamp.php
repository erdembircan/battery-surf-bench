<?php
/**
 * Franked stamp — a postage stamp with a cancellation postmark stamped over it.
 *
 * @package ErdemBircan\BatterySurfBench
 */

namespace ErdemBircan\BatterySurfBench\Cockpit\Views;

use ErdemBircan\BatterySurfBench\Support\View;

use function esc_html;

defined( 'ABSPATH' ) || exit;

/**
 * A reusable franked stamp: a perforated postage stamp with — when enabled — a
 * round cancellation postmark stamped over it, deliberately askew. The component
 * is absolutely-positioned so it never pushes the layout it sits on. The
 * cancellation's verdict text (the lower arc, value and unit) is left empty by
 * default and painted by the store's `renderSummary` watch, since the
 * Interactivity runtime cannot process directives inside SVG during server
 * render; a caller that needs a fixed, non-reactive postmark (e.g. the
 * unsupported-browser warning) can pass `arc`/`val`/`unit` to letter it
 * server-side instead.
 *
 * The cancellation is gated by `cancel_enabled`: the end-of-run summary franks
 * its stamp (a cancelled postmark reads as "this run is done"), while the
 * pre-run startup postcard shows a blank, uncancelled stamp. A `modifier` class
 * (e.g. `bsb-frank--warning`) recolours the postmark for distinct states.
 */
class FrankedStamp implements View {

	/**
	 * Renders the franked stamp.
	 *
	 * @param array<string, mixed> $data {
	 *     View data.
	 *
	 *     @type string $brand          Raw upper curved label (the view escapes it).
	 *     @type bool   $cancel_enabled Whether to stamp the cancellation postmark over the
	 *                                  stamp. Defaults to true; pass false for a blank stamp.
	 *     @type string $arc            Raw lower curved label for a fixed postmark; left empty
	 *                                  (painted by the summary watch) when omitted.
	 *     @type string $val            Raw centre value for a fixed postmark; empty when omitted.
	 *     @type string $unit           Raw centre unit label for a fixed postmark; empty when omitted.
	 *     @type string $modifier       Optional extra class on the stamp (e.g. `bsb-frank--warning`).
	 * }
	 * @return string The franked-stamp markup.
	 */
	public function render( array $data = array() ): string {
		$brand          = esc_html( isset( $data['brand'] ) ? (string) $data['brand'] : '' );
		$cancel_enabled = ! isset( $data['cancel_enabled'] ) || (bool) $data['cancel_enabled'];
		$arc            = esc_html( isset( $data['arc'] ) ? (string) $data['arc'] : '' );
		$val            = esc_html( isset( $data['val'] ) ? (string) $data['val'] : '' );
		$unit           = esc_html( isset( $data['unit'] ) ? (string) $data['unit'] : '' );
		$modifier       = isset( $data['modifier'] ) ? ' ' . esc_attr( (string) $data['modifier'] ) : '';

		// The cancellation postmark — only stamped when enabled. A blank stamp
		// (startup postcard) is the bare perforated stamp with no postmark over it.
		$cancel = '';
		if ( $cancel_enabled ) {
			$cancel = <<<HTML
<span class="bsb-frank__cancel">
		<svg class="bsb-frank__pm" viewBox="-60 -60 120 120" width="100%" height="100%">
			<defs>
				<path id="bsb-frank-top" d="M-40.5 0 A40.5 40.5 0 0 1 40.5 0"></path>
				<path id="bsb-frank-bot" d="M40.5 0 A40.5 40.5 0 0 1 -40.5 0"></path>
			</defs>
			<path class="bsb-frank__bar" d="M-58 -15 q 13 -5 26 0 t 26 0"></path>
			<path class="bsb-frank__bar" d="M-58 -5 q 13 -5 26 0 t 26 0"></path>
			<path class="bsb-frank__bar" d="M-58 5 q 13 -5 26 0 t 26 0"></path>
			<path class="bsb-frank__bar" d="M-58 15 q 13 -5 26 0 t 26 0"></path>
			<circle class="bsb-frank__ring" cx="0" cy="0" r="47"></circle>
			<circle class="bsb-frank__ring" cx="0" cy="0" r="34"></circle>
			<text class="bsb-frank__arc" text-anchor="middle" dominant-baseline="central"><textPath href="#bsb-frank-top" startOffset="50%">{$brand}</textPath></text>
			<text class="bsb-frank__arc" text-anchor="middle" dominant-baseline="central"><textPath class="bsb-frank__arc-text" href="#bsb-frank-bot" startOffset="50%">{$arc}</textPath></text>
			<text class="bsb-frank__val" x="0" y="-3" text-anchor="middle" dominant-baseline="central">{$val}</text>
			<text class="bsb-frank__unit" x="0" y="11" text-anchor="middle" dominant-baseline="central">{$unit}</text>
		</svg>
	</span>
HTML;
		}

		return <<<HTML
<span class="bsb-frank{$modifier}" aria-hidden="true">
	<span class="bsb-frank__stamp"></span>
	{$cancel}
</span>
HTML;
	}
}
